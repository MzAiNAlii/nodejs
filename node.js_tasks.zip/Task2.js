var obj = { 
    ahmad : 33, 

    raza : 10,

     ali : 19 

}
    
    Object.values(obj)
    
    console.log(Object.values(obj).sort())