var arr = ["Hello", "World", "java"];

var str = "world";

function check(arr) 
{
  return arr.some((elem) => elem.toUpperCase() === str.toUpperCase());
}

var x = check(arr);

console.log(x);