let prompt = require("prompt-sync")()

let number = prompt("Enter number")

console.log(number)

let check=() =>
{

     console.log( Math.floor( Math.random() * 8 ) + 1 )

}

check();


 