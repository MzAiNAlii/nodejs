//Fasly value : null, undefined , 0 , '' , NaN
// truthy values : 1, (1), ({0}), ([1]),
let x=[]
if (x) 
{
    console.log('truthy value')

}
else 
{
    console.log('falsy value')
}
  