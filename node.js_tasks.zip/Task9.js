let arr = [" "]

let arr1 = arr.fill(Array.from( Array(1001).keys() ) )

arr.shift(0)

console.log(arr1)