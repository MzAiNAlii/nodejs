
let arr1 = [2,4,6,8];
let isBelowThreshold = (currentValue) => currentValue % 2 ==0;
console.log(array1.every(isBelowThreshold));