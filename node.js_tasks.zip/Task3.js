const arr=[
    { name: "ali", livein: "Pakistan" },

    { name: "ahmad", livein: "Dubai" },

    { name: "hamza", livein: "London" },

    { name: "talha", livein:"Pakistan" },

    { name:"muraad", livein:"Pakistan" }
];

const pak=arr.filter( elem => ( elem.livein === "Pakistan" ))
        
console.log(pak);
