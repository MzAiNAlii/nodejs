const str="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"

let result = ""

const random=(number)=>{
  
    for ( let i = 0; i < number; i++ ) {

        result += str.charAt(Math.floor(Math.random() * str.length));
    }

}

(random(8))

console.log(result)


