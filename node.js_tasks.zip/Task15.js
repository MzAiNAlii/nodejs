var arr=[ " Canada ", " Belgium ", " United Arab Emirates ", " Pakistan " ]
let str=(arr)=>
{
    let longest=" "
    arr.forEach(value => {

        if( value.length > longest.length )

        {
            longest=value
        }

    })
    return longest
}
let r=str(arr)
console.log(r)