const arr = [ 1 , 2 , 3 ]

const number = 3

let arr1 = arr.map(func)

function func( value )

{

    return Math.pow( value, number)

}

console.log(arr1)