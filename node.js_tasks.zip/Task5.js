const strq = " Hello word "

const sub = strq.substring(3,6)

console.log(sub)

if(sub=="llo")

{
    console.log("ture")

}

else

{
    console.log("false")

}


   




