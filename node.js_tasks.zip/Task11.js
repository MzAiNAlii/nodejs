let arr=[1,2,3]
let arr1=[3,2,1]
arr.reverse();

function result(a, b)
{
    return a.join() == b.join();
}
 
console.log(result(arr, arr1));